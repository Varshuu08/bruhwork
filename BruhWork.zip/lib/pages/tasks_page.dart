import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/task.dart';
import '../services/streak_service.dart';

class TasksPage extends StatefulWidget {
  const TasksPage({super.key});

  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  static const String _storageKey = 'tasks';

  final List<Task> _tasks = [];

  final TextEditingController _taskController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  @override
  void dispose() {
    _taskController.dispose();
    _timeController.dispose();
    super.dispose();
  }

  // ---------------- STORAGE ----------------

  Future<void> _loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_storageKey);
    if (data == null) return;

    final List decoded = jsonDecode(data);
    setState(() {
      _tasks
        ..clear()
        ..addAll(decoded.map((e) => Task.fromJson(e)));
    });
  }

  Future<void> _saveTasks() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _storageKey,
      jsonEncode(_tasks.map((e) => e.toJson()).toList()),
    );
  }

  // ---------------- ADD TASK ----------------

  void _addTask() {
    final taskName = _taskController.text.trim();
    if (taskName.isEmpty) return;

    setState(() {
      _tasks.insert(
        0,
        Task(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          name: taskName,
          estimatedTime: int.tryParse(_timeController.text) ?? 15,
          isCompleted: false,
        ),
      );
    });

    _taskController.clear();
    _timeController.clear();
    _saveTasks();
  }

  // ---------------- EDIT TASK ----------------

  void _editTask(Task task) {
    final nameCtrl = TextEditingController(text: task.name);
    final timeCtrl = TextEditingController(text: task.estimatedTime.toString());

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Edit Task",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: 'Task name'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: timeCtrl,
              keyboardType: TextInputType.number,
              decoration:
                  const InputDecoration(labelText: 'Estimated time (min)'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  final index = _tasks.indexWhere((t) => t.id == task.id);
                  if (index != -1) {
                    _tasks[index] = _tasks[index].copyWith(
                      name: nameCtrl.text.trim(),
                      estimatedTime:
                          int.tryParse(timeCtrl.text) ?? task.estimatedTime,
                    );
                  }
                });
                _saveTasks();
                Navigator.pop(context);
              },
              child: const Text("Save Changes"),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------- TOGGLE TASK + STREAK ----------------

  Future<void> _toggleTask(String id) async {
    bool completedNow = false;

    setState(() {
      final index = _tasks.indexWhere((t) => t.id == id);
      if (index != -1) {
        final wasCompleted = _tasks[index].isCompleted;
        _tasks[index] = _tasks[index].copyWith(isCompleted: !wasCompleted);
        completedNow = !wasCompleted;
      }
    });

    await _saveTasks();

    // 🔥 Update streak only when marking task COMPLETE
    if (completedNow) {
      await StreakService.updateStreak();
    }
  }

  // ---------------- DELETE TASK ----------------

  void _deleteTask(String id) {
    setState(() {
      _tasks.removeWhere((task) => task.id == id);
    });
    _saveTasks();
  }

  // ---------------- UI ----------------

  @override
  Widget build(BuildContext context) {
    final incomplete = _tasks.where((task) => !task.isCompleted).toList();
    final completed = _tasks.where((task) => task.isCompleted).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Short-Term Tasks'),
        backgroundColor: const Color(0xffd8c1fe),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            /// ADD TASK CARD
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    TextField(
                      controller: _taskController,
                      decoration: const InputDecoration(
                        labelText: 'What are you avoiding now?',
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _timeController,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Est. Time (mins)',
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        ElevatedButton(
                          onPressed: _addTask,
                          child: const Text('Add'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            /// TASK LIST
            Expanded(
              child: ListView(
                children: [
                  ...incomplete.map(_buildTaskTile),
                  if (completed.isNotEmpty) ...[
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Text(
                        'Completed',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
                    ...completed.map(_buildTaskTile),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTaskTile(Task task) {
    return Card(
      child: ListTile(
        onTap: () => _editTask(task), // ✏️ EDIT
        leading: Checkbox(
          value: task.isCompleted,
          onChanged: (_) => _toggleTask(task.id),
        ),
        title: Text(
          task.name,
          style: TextStyle(
            decoration: task.isCompleted ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Text('${task.estimatedTime} min'),
        trailing: IconButton(
          icon: const Icon(Icons.delete, color: Color(0xfffe9f98)),
          onPressed: () => _deleteTask(task.id),
        ),
      ),
    );
  }
}
