class Friend {
  final String name;
  final int streak;

  Friend({required this.name, required this.streak});

  Map<String, dynamic> toJson() => {
        'name': name,
        'streak': streak,
      };

  factory Friend.fromJson(Map<String, dynamic> json) => Friend(
        name: json['name'],
        streak: json['streak'],
      );
}
