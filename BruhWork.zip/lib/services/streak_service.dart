import 'package:shared_preferences/shared_preferences.dart';

class StreakService {
  static const _lastDateKey = 'last_completed_date';
  static const _streakKey = 'current_streak';

  static Future<int> updateStreak() async {
    final prefs = await SharedPreferences.getInstance();
    final today = DateTime.now();
    final todayStr = "${today.year}-${today.month}-${today.day}";

    final lastDate = prefs.getString(_lastDateKey);
    int streak = prefs.getInt(_streakKey) ?? 0;

    if (lastDate == null) {
      streak = 1;
    } else {
      final last = DateTime.parse(lastDate);
      final diff = today.difference(last).inDays;

      if (diff == 1) {
        streak += 1;
      } else if (diff > 1) {
        streak = 1;
      }
    }

    await prefs.setString(_lastDateKey, todayStr);
    await prefs.setInt(_streakKey, streak);

    return streak;
  }

  static Future<int> getStreak() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_streakKey) ?? 0;
  }
}
