import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class UsagePage extends StatefulWidget {
  const UsagePage({super.key});

  @override
  State<UsagePage> createState() => _UsagePageState();
}

class _UsagePageState extends State<UsagePage> {
  static const Color chartColor = Color(0xffd8c2fd);

  final Map<String, int> appUsage = {
    'TikTok': 45,
    'Instagram': 30,
    'YouTube': 60,
    'VS Code': 120,
  };

  String formatTime(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    return h > 0 ? '$h h $m m' : '$m m';
  }

  void logWastedTime(String app, int minutes) {
    setState(() {
      appUsage[app] = (appUsage[app] ?? 0) + minutes;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Logged $minutes min on $app 🤡'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  List<BarChartGroupData> _createBarGroups() {
    return List.generate(
      appUsage.length,
      (index) => BarChartGroupData(
        x: index,
        barRods: [
          BarChartRodData(
            toY: appUsage.values.elementAt(index).toDouble(),
            color: chartColor,
            width: 18,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final keys = appUsage.keys.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Usage Details'),
        backgroundColor: chartColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "The hard numbers. Don't look away.",
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 260,
              child: BarChart(
                BarChartData(
                  barGroups: _createBarGroups(),
                  gridData: const FlGridData(show: true),
                  borderData: FlBorderData(show: false),
                  titlesData: FlTitlesData(
                    topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    leftTitles: const AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 40,
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 40,
                        getTitlesWidget: (value, meta) {
                          final index = value.toInt();
                          if (index < 0 || index >= keys.length) {
                            return const SizedBox.shrink();
                          }
                          return Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(
                              keys[index],
                              style: const TextStyle(fontSize: 10),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
            const Text(
              'Confess Your Sins',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                ElevatedButton(
                  onPressed: () => logWastedTime('TikTok', 15),
                  child: const Text('15m TikTok'),
                ),
                ElevatedButton(
                  onPressed: () => logWastedTime('Instagram', 30),
                  child: const Text('30m Instagram'),
                ),
                ElevatedButton(
                  onPressed: () => logWastedTime('YouTube', 45),
                  child: const Text('45m YouTube'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
