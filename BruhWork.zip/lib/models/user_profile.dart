class UserProfile {
  String name;
  String email;
  String phone;
  int age;
  String work;
  int productivityScore;
  String avatarBase64;

  UserProfile({
    required this.name,
    required this.email,
    required this.phone,
    required this.age,
    required this.work,
    required this.productivityScore,
    required this.avatarBase64,
  });

  UserProfile copyWith({
    String? name,
    String? email,
    String? phone,
    int? age,
    String? work,
    int? productivityScore,
    String? avatarBase64,
  }) {
    return UserProfile(
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      age: age ?? this.age,
      work: work ?? this.work,
      productivityScore: productivityScore ?? this.productivityScore,
      avatarBase64: avatarBase64 ?? this.avatarBase64,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'phone': phone,
        'age': age,
        'work': work,
        'productivityScore': productivityScore,
        'avatarBase64': avatarBase64,
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        name: json['name'],
        email: json['email'],
        phone: json['phone'],
        age: json['age'],
        work: json['work'],
        productivityScore: json['productivityScore'],
        avatarBase64: json['avatarBase64'] ?? '',
      );
}
