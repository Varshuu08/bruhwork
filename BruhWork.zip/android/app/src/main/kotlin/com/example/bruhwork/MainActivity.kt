package com.example.bruhwork

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
