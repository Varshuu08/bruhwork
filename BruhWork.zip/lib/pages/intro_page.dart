import 'package:flutter/material.dart';
import 'auth_page.dart';

class IntroPage extends StatefulWidget {
  const IntroPage({super.key});

  @override
  State<IntroPage> createState() => _IntroPageState();
}

class _IntroPageState extends State<IntroPage> {
  final PageController _roastController = PageController();
  int _currentRoast = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff6f4fb),
      body: SafeArea(
        child: Column(
          children: [
            /// 🔝 TOP BAR
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const SizedBox(width: 50),
                  Row(
                    children: List.generate(
                      6,
                      (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: _currentRoast == index ? 14 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: _currentRoast == index
                              ? const Color(0xffceb2ff)
                              : Colors.grey.shade400,
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (_) => const AuthPage()),
                      );
                    },
                    child: const Text("Skip"),
                  ),
                ],
              ),
            ),

            /// MAIN CONTENT
            Expanded(
              child: SingleChildScrollView(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// HERO
                    Center(
                      child: Column(
                        children: const [
                          Text(
                            "BruhWork 🚀",
                            style: TextStyle(
                              fontSize: 44,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Productivity, but brutally honest.",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 36),

                    /// 🔥 ROAST SWIPE BLOCK (EXPANDED)
                    _sectionTitle("Reality check (swipe if it hurts)"),

                    SizedBox(
                      height: 210,
                      child: PageView(
                        controller: _roastController,
                        onPageChanged: (i) {
                          setState(() => _currentRoast = i);
                        },
                        children: const [
                          _RoastCard(
                            title: "You said “I’ll start at 9”",
                            text:
                                "It’s 11:47 now.\nYou opened WhatsApp,\nInstagram, YouTube…\nbut not your work.",
                          ),
                          _RoastCard(
                            title: "Your to-do list is cute",
                            text:
                                "15 tasks.\n0 completed.\nRewriting the list\nis not productivity.",
                          ),
                          _RoastCard(
                            title: "Motivation is a scam",
                            text:
                                "Waiting to feel productive\nis how days disappear.",
                          ),
                          _RoastCard(
                            title: "You don’t need more apps",
                            text:
                                "You need clarity.\nAnd mild public shame.\nWe help with both 😌",
                          ),
                          _RoastCard(
                            title: "You work better under pressure",
                            text:
                                "Deadlines scare you.\nAccountability saves you.",
                          ),
                          _RoastCard(
                            title: "You’re not lazy",
                            text:
                                "You’re overwhelmed.\nWe help you focus on\nwhat actually matters.",
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 36),

                    /// WHY
                    _sectionTitle("Why BruhWork exists"),

                    _infoRow(
                      Icons.phone_android,
                      "Because your phone steals time silently",
                      "You don’t notice until the day is gone.",
                    ),
                    _infoRow(
                      Icons.warning_amber_rounded,
                      "Because planning feels productive",
                      "Execution is the real struggle.",
                    ),
                    _infoRow(
                      Icons.check_circle_outline,
                      "Because progress beats perfection",
                      "Even 10 minutes counts here.",
                    ),

                    const SizedBox(height: 36),

                    /// FEATURES (EXPANDED)
                    _sectionTitle("What BruhWork actually does"),

                    _featureTile(
                      Icons.task_alt,
                      "Smart Tasks",
                      "Break work into small, realistic actions",
                    ),
                    _featureTile(
                      Icons.timer_outlined,
                      "Time Awareness",
                      "See where your hours actually go",
                    ),
                    _featureTile(
                      Icons.local_fire_department_outlined,
                      "Daily Streaks",
                      "Miss a day? Fine. Quit? No.",
                    ),
                    _featureTile(
                      Icons.group_outlined,
                      "Friends & Accountability",
                      "Gentle pressure > motivation",
                    ),
                    _featureTile(
                      Icons.insights_outlined,
                      "Honest Dashboard",
                      "No fake productivity — just facts",
                    ),
                    _featureTile(
                      Icons.lock_outline,
                      "Offline-first",
                      "Your data stays on your device",
                    ),

                    const SizedBox(height: 36),

                    /// 💳 PRICING (3 BOXES)
                    _sectionTitle("Pricing (choose wisely)"),

                    Row(
                      children: const [
                        Expanded(
                          child: _PriceCard(
                            title: "Basic",
                            price: "Free",
                            subtitle: "For trying to improve",
                            features: [
                              "Unlimited tasks",
                              "Daily streaks",
                              "Basic dashboard",
                              "Offline usage",
                            ],
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: _PriceCard(
                            title: "Pro",
                            price: "₹199 / month",
                            highlight: true,
                            subtitle: "Most people pick this",
                            features: [
                              "Everything in Basic",
                              "Advanced analytics",
                              "Cloud backup",
                              "Friends leaderboard",
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 14),

                    const _PriceCard(
                      title: "Ultra",
                      price: "₹399 / month",
                      subtitle: "For serious grinders",
                      features: [
                        "Everything in Pro",
                        "AI productivity insights",
                        "Custom themes",
                        "Early feature access",
                        "Ultra roast mode 😈",
                      ],
                    ),

                    const SizedBox(height: 40),

                    /// CTA
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xffceb2ff),
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const AuthPage(),
                            ),
                          );
                        },
                        child: const Text(
                          "Alright,let’s fix this",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    Center(
                      child: TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const AuthPage(),
                            ),
                          );
                        },
                        child: const Text(
                          "I already messed up. Sign in.",
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// SECTION TITLE
  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  /// INFO ROW
  Widget _infoRow(IconData icon, String title, String desc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xffceb2ff)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(desc, style: const TextStyle(color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// FEATURE TILE
  Widget _featureTile(IconData icon, String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        child: ListTile(
          leading: Icon(icon, color: const Color(0xffceb2ff)),
          title:
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(subtitle),
        ),
      ),
    );
  }
}

/// 🔥 ROAST CARD
class _RoastCard extends StatelessWidget {
  final String title;
  final String text;

  const _RoastCard({required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(text, style: const TextStyle(color: Colors.grey, height: 1.4)),
          ],
        ),
      ),
    );
  }
}

/// 💳 PRICE CARD
class _PriceCard extends StatelessWidget {
  final String title;
  final String price;
  final String subtitle;
  final List<String> features;
  final bool highlight;

  const _PriceCard({
    required this.title,
    required this.price,
    required this.subtitle,
    required this.features,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: highlight ? 6 : 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: highlight
            ? const BorderSide(color: Color(0xffceb2ff), width: 2)
            : BorderSide.none,
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(subtitle,
                style: const TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 8),
            Text(price,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...features.map(
              (f) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text("• $f"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
