class Task {
  final String id;
  final String name;
  final int estimatedTime;
  final bool isCompleted;

  Task({
    required this.id,
    required this.name,
    required this.estimatedTime,
    required this.isCompleted,
  });

  Task copyWith({
    String? id,
    String? name,
    int? estimatedTime,
    bool? isCompleted,
  }) {
    return Task(
      id: id ?? this.id,
      name: name ?? this.name,
      estimatedTime: estimatedTime ?? this.estimatedTime,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }

  /// 🔑 ADD THESE METHODS (this is the "json" part)

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'estimatedTime': estimatedTime,
      'isCompleted': isCompleted,
    };
  }

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      id: json['id'],
      name: json['name'],
      estimatedTime: json['estimatedTime'],
      isCompleted: json['isCompleted'],
    );
  }
}
