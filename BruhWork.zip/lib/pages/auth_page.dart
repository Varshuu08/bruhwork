import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../bottom_nav.dart';
import '../models/user_profile.dart';
import 'intro_page.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool _isLogin = true;
  bool _obscurePassword = true; // 👁️ visibility toggle
  String _error = '';

  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _ageCtrl = TextEditingController();
  final _workCtrl = TextEditingController();

  static const _usersKey = 'bruh_users_db';
  static const _profileKey = 'bruh_user_profile';
  static const _loginKey = 'bruh_logged_in';

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _ageCtrl.dispose();
    _workCtrl.dispose();
    super.dispose();
  }

  // ---------------- STORAGE ----------------

  Future<Map<String, dynamic>> _getUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_usersKey);
    return data != null ? jsonDecode(data) : {};
  }

  Future<void> _saveUsers(Map<String, dynamic> users) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_usersKey, jsonEncode(users));
  }

  // ---------------- LOGIN ----------------

  Future<void> _login() async {
    final users = await _getUsers();
    final email = _emailCtrl.text.trim();
    final password = _passwordCtrl.text;

    if (!users.containsKey(email) || users[email]['password'] != password) {
      setState(() => _error = 'Invalid email or password');
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_loginKey, true);
    await prefs.setString(
      _profileKey,
      jsonEncode(users[email]['profile']),
    );

    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const BottomNav()),
      (_) => false,
    );
  }

  // ---------------- SIGN UP ----------------

  Future<void> _signup() async {
    if (_emailCtrl.text.trim().isEmpty ||
        _passwordCtrl.text.isEmpty ||
        _nameCtrl.text.trim().isEmpty ||
        _phoneCtrl.text.trim().isEmpty ||
        _ageCtrl.text.trim().isEmpty ||
        _workCtrl.text.trim().isEmpty) {
      setState(() => _error = 'All fields are required');
      return;
    }

    final users = await _getUsers();
    final email = _emailCtrl.text.trim();

    if (users.containsKey(email)) {
      setState(() => _error = 'Account already exists');
      return;
    }

    final profile = UserProfile(
      name: _nameCtrl.text.trim(),
      email: email,
      phone: _phoneCtrl.text.trim(),
      age: int.parse(_ageCtrl.text),
      work: _workCtrl.text.trim(),
      productivityScore: 0,
      avatarBase64: '',
    );

    users[email] = {
      'password': _passwordCtrl.text,
      'profile': profile.toJson(),
    };

    await _saveUsers(users);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_loginKey, true);
    await prefs.setString(
      _profileKey,
      jsonEncode(profile.toJson()),
    );

    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const BottomNav()),
      (_) => false,
    );
  }

  // ---------------- UI ----------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff1ebfe),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const IntroPage()),
            );
          },
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Text(
                'BruhWork 🚀',
                style: TextStyle(
                  fontSize: 38,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Stop procrastinating. Maybe.',
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 30),
              Card(
                elevation: 6,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text(
                        _isLogin ? 'Welcome Back 👋' : 'Create Account ✨',
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 14),

                      if (_error.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Text(
                            _error,
                            style: const TextStyle(color: Colors.red),
                          ),
                        ),

                      if (!_isLogin) _field('Name', _nameCtrl),
                      _field('Email', _emailCtrl),
                      if (!_isLogin) _field('Phone', _phoneCtrl),
                      if (!_isLogin) _field('Age', _ageCtrl, number: true),
                      if (!_isLogin) _field('College / Work', _workCtrl),

                      /// PASSWORD FIELD WITH VISIBILITY TOGGLE
                      _passwordField(),

                      const SizedBox(height: 20),

                      SizedBox(
                        width: double.infinity,
                        height: 48,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xffceb2ff),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          onPressed: _isLogin ? _login : _signup,
                          child: Text(
                            _isLogin ? 'Login' : 'Create Account',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 8),

                      TextButton(
                        onPressed: () {
                          setState(() {
                            _isLogin = !_isLogin;
                            _error = '';
                          });
                        },
                        child: Text(
                          _isLogin
                              ? "Don’t have an account? Sign up"
                              : "Already have an account? Login",
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// NORMAL FIELD
  Widget _field(
    String label,
    TextEditingController controller, {
    bool number = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        keyboardType: number ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  /// PASSWORD FIELD WITH 👁️ TOGGLE
  Widget _passwordField() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: _passwordCtrl,
        obscureText: _obscurePassword,
        decoration: InputDecoration(
          labelText: 'Password',
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          suffixIcon: IconButton(
            icon: Icon(
              _obscurePassword ? Icons.visibility_off : Icons.visibility,
            ),
            onPressed: () {
              setState(() {
                _obscurePassword = !_obscurePassword;
              });
            },
          ),
        ),
      ),
    );
  }
}
