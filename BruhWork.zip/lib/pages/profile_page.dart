import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user_profile.dart';
import 'auth_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  UserProfile? _user;
  bool _isEditing = false;

  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _ageCtrl = TextEditingController();
  final _workCtrl = TextEditingController();

  static const _storageKey = 'bruh_user_profile';

  /// 🔹 MOCK FRIENDS PREVIEW (replace later with real data)
  final List<Map<String, dynamic>> _friendsPreview = [
    {
      'name': 'Aarav',
      'streak': 7,
    },
    {
      'name': 'Neha',
      'streak': 12,
    },
    {
      'name': 'Rahul',
      'streak': 4,
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _ageCtrl.dispose();
    _workCtrl.dispose();
    super.dispose();
  }

  // ---------------- LOAD PROFILE ----------------

  Future<void> _loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_storageKey);

    if (data != null) {
      final profile = UserProfile.fromJson(jsonDecode(data));
      setState(() {
        _user = profile;
        _fillControllers(profile);
      });
    } else {
      final defaultUser = UserProfile(
        name: 'Your Name',
        email: 'you@example.com',
        phone: '',
        age: 18,
        work: '',
        productivityScore: 0,
        avatarBase64: '',
      );

      setState(() {
        _user = defaultUser;
        _fillControllers(defaultUser);
      });

      _saveProfile();
    }
  }

  void _fillControllers(UserProfile u) {
    _nameCtrl.text = u.name;
    _phoneCtrl.text = u.phone;
    _ageCtrl.text = u.age.toString();
    _workCtrl.text = u.work;
  }

  Future<void> _saveProfile() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(_user!.toJson()));
  }

  // ---------------- AVATAR PICKER ----------------

  Future<void> _pickAvatar() async {
    final picker = ImagePicker();
    final image =
        await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);

    if (image == null) return;

    final bytes = await File(image.path).readAsBytes();
    final base64Img = base64Encode(bytes);

    setState(() {
      _user = _user!.copyWith(avatarBase64: base64Img);
    });

    await _saveProfile();
  }

  // ---------------- SAVE EDITS ----------------

  void _saveEdits() {
    if (_nameCtrl.text.trim().isEmpty ||
        _phoneCtrl.text.trim().isEmpty ||
        _workCtrl.text.trim().isEmpty ||
        int.tryParse(_ageCtrl.text) == null) {
      _showError('All fields are required');
      return;
    }

    setState(() {
      _user = _user!.copyWith(
        name: _nameCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
        age: int.parse(_ageCtrl.text),
        work: _workCtrl.text.trim(),
      );
      _isEditing = false;
    });

    _saveProfile();
  }

  // ---------------- LOGOUT ----------------

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const AuthPage()),
      (_) => false,
    );
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------------- AVATAR ----------------

  Widget _buildAvatar() {
    return Stack(
      children: [
        CircleAvatar(
          radius: 50,
          backgroundColor: Colors.grey.shade300,
          backgroundImage: _user!.avatarBase64.isNotEmpty
              ? MemoryImage(base64Decode(_user!.avatarBase64))
              : null,
          child: _user!.avatarBase64.isEmpty
              ? const Icon(Icons.person, size: 50)
              : null,
        ),
        if (_isEditing)
          Positioned(
            bottom: 0,
            right: 0,
            child: CircleAvatar(
              radius: 16,
              backgroundColor: const Color(0xffceb2ff),
              child:
                  const Icon(Icons.camera_alt, size: 16, color: Colors.white),
            ),
          ),
      ],
    );
  }

  // ---------------- UI ----------------

  @override
  Widget build(BuildContext context) {
    if (_user == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        backgroundColor: const Color(0xffd3bdf9),
        title: const Text('Profile'),
        actions: [
          TextButton(
            onPressed: () {
              setState(() => _isEditing = !_isEditing);
            },
            child: Text(
              _isEditing ? 'Cancel' : 'Edit',
              style: const TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          /// PROFILE HEADER
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: _isEditing ? _pickAvatar : null,
                    child: _buildAvatar(),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    _user!.name,
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _user!.email,
                    style: const TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "🔥 Productivity Score: ${_user!.productivityScore}",
                    style: const TextStyle(
                      color: Color(0xffceb2ff),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          /// 👥 FRIENDS PREVIEW
          Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text(
                        "Friends",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        "View all",
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ..._friendsPreview.map(
                    (friend) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: const Color(0xffceb2ff),
                        child: Text(
                          friend['name'][0],
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                      title: Text(friend['name']),
                      subtitle: Text("🔥 ${friend['streak']} day streak"),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          /// DETAILS
          _buildField('Name', _nameCtrl, enabled: _isEditing),
          _buildField(
            'Email',
            TextEditingController(text: _user!.email),
            enabled: false,
          ),
          _buildField('Phone', _phoneCtrl, enabled: _isEditing),
          _buildField('Age', _ageCtrl, enabled: _isEditing, isNumber: true),
          _buildField('College / Work', _workCtrl, enabled: _isEditing),

          const SizedBox(height: 20),

          if (_isEditing)
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xffceb2ff),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: _saveEdits,
              child: const Text('Save Changes'),
            ),

          const SizedBox(height: 12),

          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            onPressed: _logout,
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  Widget _buildField(
    String label,
    TextEditingController controller, {
    bool enabled = true,
    bool isNumber = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        enabled: enabled,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: enabled ? Colors.white : Colors.grey.shade200,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}
