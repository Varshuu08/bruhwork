import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LongTermGoal {
  final String id;
  final String name;
  String weekStartDate; // ISO string
  List<bool> weeklyProgress; // Mon–Sun
  int streak;
  String? lastCompletedDate; // yyyy-mm-dd

  LongTermGoal({
    required this.id,
    required this.name,
    required this.weekStartDate,
    required this.weeklyProgress,
    this.streak = 0,
    this.lastCompletedDate,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'weekStartDate': weekStartDate,
        'weeklyProgress': weeklyProgress,
        'streak': streak,
        'lastCompletedDate': lastCompletedDate,
      };

  factory LongTermGoal.fromJson(Map<String, dynamic> json) => LongTermGoal(
        id: json['id'],
        name: json['name'],
        weekStartDate: json['weekStartDate'],
        weeklyProgress: List<bool>.from(json['weeklyProgress']),
        streak: json['streak'],
        lastCompletedDate: json['lastCompletedDate'],
      );
}

class GoalsPage extends StatefulWidget {
  const GoalsPage({super.key});

  @override
  State<GoalsPage> createState() => _GoalsPageState();
}

class _GoalsPageState extends State<GoalsPage> {
  final List<LongTermGoal> _goals = [];
  final TextEditingController _controller = TextEditingController();

  static const String _storageKey = 'bruh_long_term_goals';

  @override
  void initState() {
    super.initState();
    _loadGoals();
  }

  // ----------------- DATE HELPERS -----------------

  DateTime _startOfWeek(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    return d.subtract(Duration(days: d.weekday - 1));
  }

  bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  bool _consecutiveDays(DateTime a, DateTime b) =>
      a.difference(b).inDays.abs() == 1;

  // ----------------- STORAGE -----------------

  Future<void> _loadGoals() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_storageKey);

    if (data != null) {
      final List decoded = jsonDecode(data);
      setState(() {
        _goals.clear();
        _goals.addAll(decoded.map((e) => LongTermGoal.fromJson(e)));
      });
    }

    _resetWeekIfNeeded();
  }

  Future<void> _saveGoals() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _storageKey,
      jsonEncode(_goals.map((g) => g.toJson()).toList()),
    );
  }

  // ----------------- LOGIC -----------------

  void _resetWeekIfNeeded() {
    final now = DateTime.now();
    final thisWeek = _startOfWeek(now);

    setState(() {
      for (final goal in _goals) {
        final goalWeek = DateTime.parse(goal.weekStartDate);
        if (!_sameDay(goalWeek, thisWeek)) {
          goal.weekStartDate = thisWeek.toIso8601String();
          goal.weeklyProgress = List.filled(7, false);
        }
      }
    });

    _saveGoals();
  }

  void _addGoal() {
    if (_controller.text.trim().isEmpty) return;

    final weekStart = _startOfWeek(DateTime.now());

    setState(() {
      _goals.insert(
        0,
        LongTermGoal(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          name: _controller.text.trim(),
          weekStartDate: weekStart.toIso8601String(),
          weeklyProgress: List.filled(7, false),
        ),
      );
      _controller.clear();
    });

    _saveGoals();
  }

  void _toggleDay(LongTermGoal goal, int dayIndex) {
    final today = DateTime.now();
    final todayIndex = today.weekday - 1;

    if (dayIndex > todayIndex) return;

    setState(() {
      goal.weeklyProgress[dayIndex] = !goal.weeklyProgress[dayIndex];

      final todayDate = DateTime(today.year, today.month, today.day);
      DateTime? last = goal.lastCompletedDate != null
          ? DateTime.parse(goal.lastCompletedDate!)
          : null;

      if (goal.weeklyProgress[dayIndex]) {
        if (last == null) {
          goal.streak = 1;
        } else if (_consecutiveDays(todayDate, last)) {
          goal.streak += 1;
        } else if (!_sameDay(todayDate, last)) {
          goal.streak = 1;
        }
        goal.lastCompletedDate = todayDate.toIso8601String().split('T')[0];
      } else {
        if (last != null && _sameDay(todayDate, last)) {
          goal.streak = (goal.streak - 1).clamp(0, 9999);
          goal.lastCompletedDate = null;
        }
      }
    });

    _saveGoals();
  }

  void _deleteGoal(String id) {
    setState(() {
      _goals.removeWhere((g) => g.id == id);
    });
    _saveGoals();
  }

  // ----------------- UI -----------------

  @override
  Widget build(BuildContext context) {
    final todayIndex = DateTime.now().weekday - 1;
    const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Long-Term Goals'),
        backgroundColor: Color(0xffd1bbf9),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'e.g. Learn Python',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _addGoal,
                  child: const Text('Add'),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: _goals.isEmpty
                  ? const Center(
                      child: Text(
                        'No long-term goals. Planning is overrated anyway.',
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _goals.length,
                      itemBuilder: (context, index) {
                        final goal = _goals[index];
                        final completed =
                            goal.weeklyProgress.where((e) => e).length;
                        final progress = completed / 7;

                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(goal.name,
                                            style: const TextStyle(
                                                fontWeight: FontWeight.bold)),
                                        Text(
                                          goal.streak > 0
                                              ? '🔥 ${goal.streak} day streak'
                                              : 'No streak yet. Pathetic.',
                                          style: const TextStyle(
                                              fontSize: 12, color: Colors.grey),
                                        ),
                                      ],
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete,
                                          color: Colors.red),
                                      onPressed: () => _deleteGoal(goal.id),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: List.generate(7, (i) {
                                    return Column(
                                      children: [
                                        Text(
                                          days[i],
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: i == todayIndex
                                                ? Color(0xffdfcefb)
                                                : Colors.grey,
                                          ),
                                        ),
                                        Checkbox(
                                          value: goal.weeklyProgress[i],
                                          onChanged: i <= todayIndex
                                              ? (_) => _toggleDay(goal, i)
                                              : null,
                                        ),
                                      ],
                                    );
                                  }),
                                ),
                                LinearProgressIndicator(
                                  value: progress,
                                  minHeight: 6,
                                ),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    '${(progress * 100).round()}% this week',
                                    style: const TextStyle(
                                        fontSize: 12, color: Colors.grey),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
