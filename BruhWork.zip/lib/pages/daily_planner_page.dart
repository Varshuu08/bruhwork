import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PlannerTask {
  final String id;
  final String text;
  bool isCompleted;

  PlannerTask({
    required this.id,
    required this.text,
    this.isCompleted = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'isCompleted': isCompleted,
      };

  factory PlannerTask.fromJson(Map<String, dynamic> json) => PlannerTask(
        id: json['id'],
        text: json['text'],
        isCompleted: json['isCompleted'],
      );
}

class DailyPlannerPage extends StatefulWidget {
  const DailyPlannerPage({super.key});

  @override
  State<DailyPlannerPage> createState() => _DailyPlannerPageState();
}

class _DailyPlannerPageState extends State<DailyPlannerPage> {
  final List<PlannerTask> _tasks = [];
  final TextEditingController _controller = TextEditingController();

  String get _plannerKey {
    final today = DateTime.now();
    final date = today.toIso8601String().split('T')[0];
    return 'bruhPlannerTasks_$date';
  }

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  Future<void> _loadTasks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final data = prefs.getString(_plannerKey);
      if (data != null) {
        final List decoded = jsonDecode(data);
        setState(() {
          _tasks.clear();
          _tasks.addAll(
            decoded.map((e) => PlannerTask.fromJson(e)).toList(),
          );
        });
      }
    } catch (e) {
      debugPrint('Failed to load planner tasks');
    }
  }

  Future<void> _saveTasks() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final encoded = jsonEncode(_tasks.map((e) => e.toJson()).toList());
      await prefs.setString(_plannerKey, encoded);
    } catch (e) {
      debugPrint('Failed to save planner tasks');
    }
  }

  void _addTask() {
    if (_controller.text.trim().isEmpty) return;

    setState(() {
      _tasks.insert(
        0,
        PlannerTask(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          text: _controller.text.trim(),
        ),
      );
      _controller.clear();
    });

    _saveTasks();
  }

  void _toggleTask(String id) {
    setState(() {
      final task = _tasks.firstWhere((t) => t.id == id);
      task.isCompleted = !task.isCompleted;
    });
    _saveTasks();
  }

  void _deleteTask(String id) {
    setState(() {
      _tasks.removeWhere((t) => t.id == id);
    });
    _saveTasks();
  }

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final formattedDate =
        '${_weekday(today.weekday)}, ${_month(today.month)} ${today.day}';

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text("Today's Plan"),
        backgroundColor: Color(0xffc6a8f9),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              formattedDate,
              style: const TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 16),

            /// ADD TASK
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: "What's the plan for today?",
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _addTask,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xffefe9f9),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                  ),
                  child: const Text('Add'),
                ),
              ],
            ),

            const SizedBox(height: 20),

            /// TASK LIST
            Expanded(
              child: _tasks.isEmpty
                  ? const Center(
                      child: Text(
                        'No tasks for today. Go ahead, be lazy.',
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _tasks.length,
                      itemBuilder: (context, index) {
                        final task = _tasks[index];
                        return Card(
                          child: ListTile(
                            leading: Checkbox(
                              value: task.isCompleted,
                              onChanged: (_) => _toggleTask(task.id),
                            ),
                            title: Text(
                              task.text,
                              style: TextStyle(
                                decoration: task.isCompleted
                                    ? TextDecoration.lineThrough
                                    : null,
                              ),
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _deleteTask(task.id),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  String _weekday(int day) =>
      ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][day - 1];

  String _month(int month) => [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec'
      ][month - 1];
}
