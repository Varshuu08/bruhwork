import 'package:flutter/material.dart';

// Your existing pages
import 'pages/intro_page.dart';
import 'pages/auth_page.dart';
import 'bottom_nav.dart';

void main() {
  runApp(const BruhWorkApp());
}

class BruhWorkApp extends StatelessWidget {
  const BruhWorkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      // ✅ Always start with Intro Page
      home: const IntroPage(),

      // (Optional) Named routes if you want them later
      routes: {
        '/intro': (context) => const IntroPage(),
        '/auth': (context) => const AuthPage(),
        '/home': (context) => const BottomNav(),
      },
    );
  }
}
