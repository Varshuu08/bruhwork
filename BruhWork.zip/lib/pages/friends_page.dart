import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/friend.dart';

class FriendsPage extends StatefulWidget {
  const FriendsPage({super.key});

  @override
  State<FriendsPage> createState() => _FriendsPageState();
}

class _FriendsPageState extends State<FriendsPage> {
  static const _key = 'friends';
  final List<Friend> friends = [];

  @override
  void initState() {
    super.initState();
    loadFriends();
  }

  Future<void> loadFriends() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_key);
    if (data == null) return;

    final List decoded = jsonDecode(data);
    setState(() {
      friends.clear();
      friends.addAll(decoded.map((e) => Friend.fromJson(e)));
    });
  }

  Future<void> saveFriends() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _key,
      jsonEncode(friends.map((e) => e.toJson()).toList()),
    );
  }

  void addFriend(String name) {
    setState(() {
      friends.add(Friend(name: name, streak: 0));
    });
    saveFriends();
  }

  void showAddFriend() {
    final ctrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ctrl,
              decoration: const InputDecoration(
                labelText: "Friend's name",
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                if (ctrl.text.trim().isNotEmpty) {
                  addFriend(ctrl.text.trim());
                  Navigator.pop(context);
                }
              },
              child: const Text("Add Friend"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Friends")),
      floatingActionButton: FloatingActionButton(
        onPressed: showAddFriend,
        child: const Icon(Icons.person_add),
      ),
      body: friends.isEmpty
          ? const Center(child: Text("No friends added yet"))
          : ListView.builder(
              itemCount: friends.length,
              itemBuilder: (_, i) {
                final f = friends[i];
                return ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(f.name),
                  trailing: Text("🔥 ${f.streak}"),
                );
              },
            ),
    );
  }
}
