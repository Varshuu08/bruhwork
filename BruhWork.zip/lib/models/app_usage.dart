enum AppCategory {
  productive,
  neutral,
  distracting,
}

class AppUsage {
  final String id;
  String name;
  int timeSpent; // minutes
  AppCategory category;

  AppUsage({
    required this.id,
    required this.name,
    required this.timeSpent,
    required this.category,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'timeSpent': timeSpent,
        'category': category.name,
      };

  factory AppUsage.fromJson(Map<String, dynamic> json) => AppUsage(
        id: json['id'],
        name: json['name'],
        timeSpent: json['timeSpent'],
        category: AppCategory.values.firstWhere(
          (e) => e.name == json['category'],
        ),
      );
}
