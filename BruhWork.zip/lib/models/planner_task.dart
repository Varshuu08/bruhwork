class PlannerTask {
  final String id;
  String text;
  bool isCompleted;

  PlannerTask({
    required this.id,
    required this.text,
    this.isCompleted = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'isCompleted': isCompleted,
      };

  factory PlannerTask.fromJson(Map<String, dynamic> json) => PlannerTask(
        id: json['id'],
        text: json['text'],
        isCompleted: json['isCompleted'],
      );
}
