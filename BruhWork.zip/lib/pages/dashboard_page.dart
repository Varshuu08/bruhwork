import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

import '../models/task.dart';
import '../services/task_storage.dart';
import '../services/streak_service.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  static const Color productiveColor = Color(0xff9cf29f);
  static const Color neutralColor = Color(0xfffbd398);
  static const Color distractingColor = Color(0xfff9948d);
  static const Color appBarColor = Color(0xffceb2ff);

  int productive = 120;
  int neutral = 40;
  int distracting = 75;

  List<Task> tasks = [];
  int streak = 0;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    final loadedTasks = await TaskStorage.getTasks();
    final currentStreak = await StreakService.getStreak();

    setState(() {
      tasks = loadedTasks;
      streak = currentStreak;
    });
  }

  int get totalTime => productive + neutral + distracting;
  int get completedTasks => tasks.where((t) => t.isCompleted).length;
  int get pendingTasks => tasks.where((t) => !t.isCompleted).length;

  String formatTime(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    return h > 0 ? '$h h $m m' : '$m m';
  }

  // ---------------- PIE CHART ----------------

  Widget _buildPieChart() {
    return SizedBox(
      height: 200,
      child: PieChart(
        PieChartData(
          centerSpaceRadius: 50,
          sectionsSpace: 3,
          sections: [
            PieChartSectionData(
              value: productive.toDouble(),
              color: productiveColor,
              title: 'Work',
              radius: 60,
              titleStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            PieChartSectionData(
              value: neutral.toDouble(),
              color: neutralColor,
              title: 'Neutral',
              radius: 60,
              titleStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            PieChartSectionData(
              value: distracting.toDouble(),
              color: distractingColor,
              title: 'Distracting',
              radius: 60,
              titleStyle: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------- UPCOMING TASKS ----------------

  Widget _buildUpcomingTasks() {
    final upcoming = tasks.where((t) => !t.isCompleted).take(3).toList();

    if (upcoming.isEmpty) {
      return const Text(
        "No pending tasks. Either you're productive… or lying 😌",
        style: TextStyle(color: Colors.grey),
      );
    }

    return Column(
      children: upcoming
          .map(
            (task) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.circle_outlined, color: appBarColor),
              title: Text(task.name),
              subtitle: Text('${task.estimatedTime} min'),
            ),
          )
          .toList(),
    );
  }

  // ---------------- UI ----------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: appBarColor,
        title: const Text('Dashboard'),
      ),
      body: RefreshIndicator(
        onRefresh: _loadAll,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Here’s your brutally honest reality check.",
                style: TextStyle(color: Colors.grey),
              ),

              const SizedBox(height: 20),

              /// 🔥 STREAK
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                child: ListTile(
                  leading: const Icon(
                    Icons.local_fire_department,
                    color: Colors.orange,
                    size: 32,
                  ),
                  title: const Text(
                    "Current Streak",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  trailing: Text(
                    "$streak days",
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              /// SCREEN TIME
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Today's Screen Time",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        formatTime(totalTime),
                        style: const TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: appBarColor,
                        ),
                      ),
                      const SizedBox(height: 16),
                      _buildPieChart(),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              /// TASK COUNTS
              Row(
                children: [
                  Expanded(
                    child: _statCard(
                      title: "Completed",
                      value: completedTasks,
                      color: Colors.green,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _statCard(
                      title: "Pending",
                      value: pendingTasks,
                      color: Colors.redAccent,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              /// UPCOMING TASKS
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Upcoming Tasks",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      _buildUpcomingTasks(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// SMALL STAT CARD
  Widget _statCard({
    required String title,
    required int value,
    required Color color,
  }) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Text(
              title,
              style: const TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 6),
            Text(
              "$value",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
